#!/usr/bin/env python

# procedural 
print('Hello I am line 1.')
print('Hello I am line 2.')

a = 1
b = 2
c = a + b 
print(c)


