#!/usr/bin/env python

# create a new object
class Section5Class():
    def printbot(self, say_something):
        print(say_something)

    def add_two(self, i: int, j: int):
        return int(i) + int(j) 


if __name__ == "__main__":
    # instantiate first time
    new_class_1 = Section5Class()
    new_class_1.printbot('Hello I am line 1 from new_class_1.')
    new_class_1.printbot('Hello I am line 2 from new_class_1.')
    result = new_class_1.add_two(1, 2)
    print(result)

    # instantiate second time
    new_class_2 = Section5Class()
    new_class_2.printbot('Hello I am line 1 from new_class_2.')
    new_class_2.printbot('Hello I am line 2 from new_class_2.')
    result = new_class_2.add_two(1, 2)
    print(result)


