#!/usr/bin/env python

# create a new object
class Section5Class():
    def printbot(self, say_something):
        print(say_something)

    def add_two(self, i: int, j: int):
        return int(i) + int(j) 



