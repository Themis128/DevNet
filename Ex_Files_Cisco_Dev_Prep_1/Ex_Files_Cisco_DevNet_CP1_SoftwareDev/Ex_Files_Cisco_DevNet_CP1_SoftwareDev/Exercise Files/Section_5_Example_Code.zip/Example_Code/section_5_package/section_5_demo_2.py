#!/usr/bin/env python

def printbot(say_something):
    print(say_something)

# Python 3 type hints: https://docs.python.org/3/library/typing.html
def add_two(i:int, j:int):
    return i + j 

# example from slides on functions
def router_name(location, name):
    full_name = location + "-" + name 
    return full_name


# refer to printbot function above
printbot('Hello I am line 1.')
printbot('Hello I am line 2.')

# refer to add_two function above
result = add_two(1, 2)
print(result)

router = router_name('lax', 'r1')
print("The router name is {}".format(router))

