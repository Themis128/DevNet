#!/usr/bin/env python

# Note the structure of the section_5_package and the __init__.py file (empty)

# define my own printbot
def printbot(say_something):
    print(say_something)

printbot('I am printbot.')

# To use section_5_demo_2.py functions
import section_5_demo_2

section_5_demo_2.printbot('I am printbot from section_5_demo_2.')

# To use section_5_demo_3.py class
import section_5_demo_3

new_class = section_5_demo_3.Section5Class()
new_class.printbot('I am printbot from section_5_demo3 Section5Class.')

# To use section_5_package
# the following loads the module from package
import section_5_package.section_5_demo_2
from section_5_package.section_5_demo_3 import Section5Class 
section_5_package.section_5_demo_2.printbot('I am printbot from section_5_package / section_5_demo_2')
new_class_1 = Section5Class()
new_class_1.printbot('I am printbot from section_5_pacakge / section_5_demo_3.Section5Class')
